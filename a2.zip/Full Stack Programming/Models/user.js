const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: [true, 'First name is required'],
    trim: true
  },
  lastName: {
    type: String,
    required: [true, 'Last name is required'],
    trim: true
  },
  age: {
    type: Number,
    min: [18, 'Age must be at least 18'],
    required: [true, 'Age is required']
  },
  dob: {
    type: Date,
    required: [true, 'Date of birth is required']
  },
  licenseNumber: {
    type: String,
    unique: true,
    required: [true, 'License number is required'],
    trim: true
  },
  car: {
    make: {
      type: String,
      required: [true, 'Car make is required'],
      trim: true
    },
    model: {
      type: String,
      required: [true, 'Car model is required'],
      trim: true
    },
    year: {
      type: Number,
      min: [1900, 'Year must be at least 1900'],
      max: [new Date().getFullYear(), 'Year must not be in the future'],
      required: [true, 'Car year is required']
    },
    plateNumber: {
      type: String,
      required: [true, 'Plate number is required'],
      trim: true
    }
  }
}, {
  timestamps: true,
  versionKey: false
});

const User = mongoose.model('User', userSchema);
module.exports = User;