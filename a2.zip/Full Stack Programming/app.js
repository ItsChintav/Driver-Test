const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const User = require('./Models/user');

const PORT = 5000;
const app = express();

// Set up middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set view engine to EJS
app.set('view engine', 'ejs');
app.set('views', './views');

// MongoDB connection
mongoose.connect('mongodb+srv://ctrivedi7361:du4RT3ighuWUTecX@cluster0.nlwtn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Connected to MongoDB');
})
.catch(err => {
  console.error('Connection failed', err);
});

// Routes

// Home page
app.get('/', (req, res) => {
  res.render('home');
});

// Dashboard page
app.get('/Dashboard', (req, res) => {
  res.render('dashboard');
});

// Login page
app.get('/Login', (req, res) => {
  res.render('login');
});

// G2 Page - Form to add user data
app.get('/G2', (req, res) => {
  res.render('g2');
});

// Handle form submission from G2 page
app.post('/G2', async (req, res) => {
  try {
    const { firstName, lastName, licenseNumber, age, dob, make, model, year, platno } = req.body;

    // Validation checks
    if (!firstName || !lastName || !licenseNumber || !age || !make || !model || !year || !platno) {
      return res.status(400).send('All fields are required.');
    }

    if (licenseNumber.length !== 8) {
      return res.status(400).send('License number must be exactly 8 characters long.');
    }

    if (isNaN(age) || age <= 0) {
      return res.status(400).send('Age must be a positive number.');
    }

    // Create new user
    const newUser = new User({
      firstName,
      lastName,
      age,
      dob,
      licenseNumber: { licenseNumber },
      car: {
        make,
        model,
        year,
        plateNumber: platno
      }
    });
    await newUser.save();
    console.log('User saved successfully:', newUser); // Log saved user data for debugging
    res.redirect('/G2');
  } catch (error) {
    console.error('Error saving user:', error);
    res.status(500).send('Error saving user.');
  }
});

// G Page - Fetch user data by License Number
app.get('/G', (req, res) => {
  res.render('g', { user: null, message: null });
});

// Handle form submission to lookup user data by License Number
app.post('/lookup-g-license', async (req, res) => {
  try {
    const { licenseNumber } = req.body;
    const user = await User.findOne({ 'licenseNumber.licenseNumber': licenseNumber });

    if (!user) {
      console.log('No user found for License Number:', licenseNumber); // Log if no user is found
      return res.render('g', { user: null, message: 'No license information available.' });
    }

    console.log('User found:', user); // Log user data found
    res.render('g', { user, message: null });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).send('Error fetching user data.');
  }
});

// Handle form submission to update car details from G page
app.post('/update-car-details', async (req, res) => {
  try {
    const { licenseNo, make, model, year, platno } = req.body;
    const updateResult = await User.updateOne(
      { 'licenseNumber.licenseNumber': licenseNo },
      {
        $set: {
          'car.make': make,
          'car.model': model,
          'car.year': year,
          'car.plateNumber': platno
        }
      }
    );

    if (updateResult.matchedCount === 0) {
      console.log('No user found for update:', licenseNo); // Log if no user is found for updating
      return res.status(404).send('User with the given license number not found.');
    }

    console.log('Car details updated successfully'); // Log successful update
    res.redirect('/G');
  } catch (error) {
    console.error('Error updating car details:', error);
    res.status(500).send('Error updating car details.');
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});